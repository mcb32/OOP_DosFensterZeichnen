//============================================================================
// Name        : Main.cpp  f�r Operationen rund um das DOS Fenster
// Author      : rma 1.12.2016
// Version     : 3.0
/* Description : Zeigt den Einsatz von Klassen, Methoden und Attributen
   ============================================================================   */
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include "gotoxy_clrscr.h"
// 
#include  <iostream>  
#include "classZeichnen.h"
// #include "xy_Lib.h"
using namespace std;       // damit cout und cin erreichbar sind ohne immer std::cin schreiben zu m�ssen :-)
// ---------------------------------------------------


unsigned int  AnzahlRs=0;    // Die Anzahl von Widerst�nden welche er�ffnet wurde. siehe http://www2.informatik.uni-halle.de/lehre/c/c_globv.html

// Prototypen lokale Funktionen ---------------------------------------------------
void abbrechen(void);      // Prototyp f�r Abbruch der Ausgabe. 


// --------------------------------------------------------------------------------

/*     MAIN Programm           */
int main () {
	SetConsoleDimension(0, 0, 79, 60,79+1, 60+60);   // setze DOS Fenster neu auf. 
	SetConsoleTitle(TEXT("My first Step with DOS Windows GAMES"));
 
	cZeichnen Kreis1;
	cZeichnen Kreis2;
	Kreis1.zeichneKreis(12, 6, 5, 12, 12);
	Kreis2.zeichneKreis(44, 6, 5, 12, 12);
	Kreis2.zeichneKreis(45, 6, 5, 0, 12);
	

  //initDosWindow();
  //zeichne_rahmen();    // ------ Zeichnen des Rahmens ---------------

  // printf("DEMO");
  // Achsen zeichnen -------------------------------------
  // zeichne_achse();
  // beschrifte_xachse(10);           // beschrifte x Achse, setze an jeder 10Stelle eine Beschriftung
  // Ende DEMO ------------------------------------------------


  abbrechen();
  return 0;
}





/* Funktionen ausprogrammiert.    */
void abbrechen(void) {
  char tempin;// Warte auf Abbruch der Ausgabe 
  gotoxy(20,22); cout << "Abbruch mit j/J" ;
  do {
    cin >> tempin;
	} while (  ! ((tempin == ('j'))  ||  (tempin == ('J')))   );
}