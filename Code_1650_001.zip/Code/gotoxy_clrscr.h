#ifndef _gotoxy_clscr_     // Pr�fe ob der Begriff _gotoxy_clscr_ schon dem Pr�prozesor  bekannt ist. Wenn nein dann ......
#define _gotoxy_clscr_      // Wenn der Begriff _Widerstandsrechner_H nicht bekannt ist dann definiere ihn nun (bis #endif) 
        // http://msdn.microsoft.com/query/dev10.query?appId=Dev10IDEF1&l=DE-DE&k=k(%22%23IFNDEF%22);k(DevLang-%22C%2B%2B%22)&rd=true
        // https://msdn.microsoft.com/en-us/library/windows/desktop/ms686125(v=vs.85).aspx

//Funktion die wir aus dem Internet haben von folgender Seite:http://board.gulli.com/thread/659029-gotoxy-in-c/
// see https://www.c-plusplus.net/forum/146221-full, http://benryves.com/tutorials/winconsole/
// for more details about colors in DOS Box

#include <windows.h>

// ---------------------------------
void gotoxy(int xpos, int ypos);
void SetConsoleDimension(int x0, int y0, int x1, int y1, int buffx, int buffy);
void zeichne_rahmen(void);
void zeichne_achse(void);
void beschrifte_xachse(unsigned char dx);
void initDosWindow();
//
#endif
